﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FC05_WRITE_SINGLE_COIL
{
    public partial class FormMain : Form
    {
        private SerialPort serialPort1 = null;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            try
            {
                serialPort1 = new SerialPort("COM1", 9600, Parity.None, 8, StopBits.One);
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnON_Click(object sender, EventArgs e)
        {
            try
            {
                byte slaveAddress = 1;
                byte function = 5;
                ushort startAddress = 0; 
                const bool ON = true;
                if (serialPort1.IsOpen)
                {
                    byte[] frame = WriteSingleCoilMsg(slaveAddress, startAddress, function, ON);
                    txtSendMsg.Text = Display(frame);
                    serialPort1.Write(frame, 0, frame.Length);
                    Thread.Sleep(100); // Delay 100ms
                    if (serialPort1.BytesToRead >= 5)
                    {
                        byte[] bufferReceiver = new byte[this.serialPort1.BytesToRead];
                        serialPort1.Read(bufferReceiver, 0, serialPort1.BytesToRead);
                        serialPort1.DiscardInBuffer();
                        txtReceiMsg.Text = Display(bufferReceiver);  
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnOFF_Click(object sender, EventArgs e)
        {
            try
            {
                byte slaveAddress = 1;
                byte function = 5;
                ushort startAddress = 0;
                const bool OFF = false;
                if (serialPort1.IsOpen)
                {
                    byte[] frame = WriteSingleCoilMsg(slaveAddress, startAddress, function, OFF);
                    txtSendMsg.Text = Display(frame);
                    serialPort1.Write(frame, 0, frame.Length);
                    Thread.Sleep(100); // Delay 100ms
                    if (serialPort1.BytesToRead >= 5)
                    {
                        byte[] bufferReceiver = new byte[this.serialPort1.BytesToRead];
                        serialPort1.Read(bufferReceiver, 0, serialPort1.BytesToRead);
                        serialPort1.DiscardInBuffer();
                        txtReceiMsg.Text = Display(bufferReceiver);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private byte[] WriteSingleCoilMsg(byte slaveAddress, ushort startAddress, byte functionCode, bool value)
        {
            byte[] frame = new byte[8]; // Message size
            frame[0] = slaveAddress; // Slave address
            frame[1] = functionCode; // Function code            
            frame[2] = (byte)(startAddress >> 8); // Coil Address Hi
            frame[3] = (byte)startAddress; // Coil Address Lo
            frame[4] = (byte)(value ? 0xFF : 0x0); //Write Data Hi
            frame[5] = 0x00; //Write Data Lo
            byte[] crc = CalculateCRC(frame); // Calculate CRC.
            frame[frame.Length - 2] = crc[0]; //Error Check Lo
            frame[frame.Length - 1] = crc[1]; //Error Check Hi
            return frame;
        }

        /// <summary>
        /// CRC Calculation 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private byte[] CalculateCRC(byte[] data)
        {
            ushort CRCFull = 0xFFFF; // Set the 16-bit register (CRC register) = FFFFH.
            byte CRCHigh = 0xFF, CRCLow = 0xFF;
            char CRCLSB;
            byte[] CRC = new byte[2];
            for (int i = 0; i < (data.Length) - 2; i++)
            {
                CRCFull = (ushort)(CRCFull ^ data[i]); // 

                for (int j = 0; j < 8; j++)
                {
                    CRCLSB = (char)(CRCFull & 0x0001);
                    CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF);

                    if (CRCLSB == 1)
                        CRCFull = (ushort)(CRCFull ^ 0xA001);
                }
            }
            CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF);
            CRC[0] = CRCLow = (byte)(CRCFull & 0xFF);
            return CRC;
        }

        /// <summary>
        /// Display Data
        /// </summary>
        /// <param name="data">Data</param>
        /// <returns>Message</returns>
        private string Display(byte[] data)
        {
            string result = string.Empty;
            foreach (var item in data)
            {
                result += string.Format("{0:X2}", item);
            }
            return result;
        }
    }
}
