﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FC01_READ_COIL_STATUS
{
    public partial class FormMain : Form
    {
        private SerialPort serialPort1 = null;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            try
            {
                serialPort1 = new SerialPort("COM1", 9600, Parity.None, 8, StopBits.One);
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReadCoils_Click(object sender, EventArgs e)
        {
            try
            {
                byte slaveAddress = 4;
                byte function = 1;
                ushort startAddress = 10; // 10 decimal = A hexa
                uint numberOfPoints = 13; // 13 decimal = D hexa

                byte[] frame = ReadCoilsMsg(slaveAddress, startAddress, function, numberOfPoints);
                txtSendMsg.Text = Display(frame);
                if (serialPort1.IsOpen)
                {
                    serialPort1.Write(frame, 0, frame.Length);
                    Thread.Sleep(100); // Delay 100ms
                    if (serialPort1.BytesToRead >= 5)
                    {
                        byte[] bufferReceiver = new byte[this.serialPort1.BytesToRead];
                        serialPort1.Read(bufferReceiver, 0, serialPort1.BytesToRead);
                        serialPort1.DiscardInBuffer();
                        txtReceiMsg.Text = Display(bufferReceiver);

                        // Process data.
                        byte[] data = new byte[bufferReceiver.Length - 5];
                        Array.Copy(bufferReceiver, 3, data, 0, data.Length);
                        bool[] temp = ByteToBool(data);
                        string result = string.Empty;
                        foreach (var item in temp)
                        {
                            result += string.Format("{0} ", item);
                        }
                        txtResult.Text = result;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        /// Convert byte array to bool array.
        /// </summary>
        /// <param name="value">byte array</param>
        /// <returns>bool array</returns>
        private bool[] ByteToBool(byte[] value)
        {
            List<bool> result = new List<bool>();
            BitArray bits = new BitArray(value);
            for (int i = 0; i < bits.Count; i++)
            {
                result.Add(bits[i]);
            }
            return result.ToArray();
        }

        /// <summary>
        /// Function 01 (01hex) Read Coils
        /// Reads the ON/OFF status of discrete coils in the slave.
        /// </summary>
        /// <param name="slaveAddress">Slave Address</param>
        /// <param name="startAddress">Starting Address</param>
        /// <param name="function">Function</param>
        /// <param name="numberOfPoints">Quantity of Coils</param>
        /// <returns>Byte Array</returns>
        private byte[] ReadCoilsMsg(byte slaveAddress, ushort startAddress, byte function, uint numberOfPoints)
        {
            byte[] frame = new byte[8];
            frame[0] = slaveAddress;			    // Slave Address
            frame[1] = function;				    // Function             
            frame[2] = (byte)(startAddress >> 8);	// Starting Address High
            frame[3] = (byte)startAddress;		    // Starting Address Low            
            frame[4] = (byte)(numberOfPoints >> 8);	// Quantity of Coils High
            frame[5] = (byte)numberOfPoints;		// Quantity of Coils Low
            byte[] crc = this.CalculateCRC(frame);  // Calculate CRC.
            frame[frame.Length - 2] = crc[0];       // Error Check Low
            frame[frame.Length - 1] = crc[1];       // Error Check High
            return frame;
        }


        /// <summary>
        /// CRC Calculation 
        /// </summary>
        /// <param name="data">byte[]</param>
        /// <returns>byte[]</returns>
        private byte[] CalculateCRC(byte[] data)
        {
            ushort CRCFull = 0xFFFF; // Set the 16-bit register (CRC register) = FFFFH.
            byte CRCHigh = 0xFF, CRCLow = 0xFF;
            char CRCLSB;
            byte[] CRC = new byte[2];
            for (int i = 0; i < (data.Length) - 2; i++) 
            {
                CRCFull = (ushort)(CRCFull ^ data[i]);  // XOR byte into least sig. byte of crc

                for (int j = 0; j < 8; j++)// Loop over each bit
                {
                    CRCLSB = (char)(CRCFull & 0x0001);
                    CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF);

                    if (CRCLSB == 1)
                        CRCFull = (ushort)(CRCFull ^ 0xA001);
                }
            }
            CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF);
            CRC[0] = CRCLow = (byte)(CRCFull & 0xFF);
            return CRC;
        }

        /// <summary>
        /// Display Data
        /// </summary>
        /// <param name="data">Data</param>
        /// <returns>Message</returns>
        private string Display(byte[] data)
        {
            string result = string.Empty;
            foreach (var item in data)
            {
                result += string.Format("{0:X2}", item);
            }
            return result;
        }

    }
}
