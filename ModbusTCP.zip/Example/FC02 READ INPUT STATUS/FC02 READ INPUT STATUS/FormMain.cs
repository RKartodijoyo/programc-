﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FC02_READ_INPUT_STATUS
{
    public partial class FormMain : Form
    {
        private const int READ_BUFFER_SIZE = 2048; // 2KB.

        private const int WRITE_BUFFER_SIZE = 2048; // 2KB.

        private byte[] bufferReceiver = null;
        private byte[] bufferSender = null;

        private Socket mSocket = null;

        private string IP = "127.0.0.1";
        private int Port = 502;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            try
            {
                Connect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                Disconnect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Connect to device
        /// </summary>
        public void Connect()
        {
            this.mSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.bufferReceiver = new byte[READ_BUFFER_SIZE];
            this.bufferSender = new byte[WRITE_BUFFER_SIZE];
            this.mSocket.SendBufferSize = READ_BUFFER_SIZE;
            this.mSocket.ReceiveBufferSize = WRITE_BUFFER_SIZE;
            IPEndPoint server = new IPEndPoint(IPAddress.Parse(this.IP), this.Port);
            this.mSocket.Connect(server); 
        }

        /// <summary>
        /// Disconnect with device
        /// </summary>
        public void Disconnect()
        {
            if (this.mSocket == null) return;
            if (this.mSocket.Connected)
            {
                this.mSocket.Close();
            }
        }

        private void btnReadDiscreteInputs_Click(object sender, EventArgs e)
        {
            try
            {
                byte slaveAddress = 4;
                byte function = 2;
                ushort id = function;
                ushort startAddress = 10; // 10 decimal = A hexa
                uint numberOfPoints = 13; // 13 decimal = D hexa

                byte[] frame = ReadDiscreteInputsMsg(id, slaveAddress, startAddress, function, numberOfPoints);
                txtSendMsg.Text = Display(frame); //Show Message sent
                this.Write(frame); // Send message
                Thread.Sleep(100); // Delay 100ms
                byte[] buffReceiver = this.Read(); // Receive messages                         

                // Process data.
                int SizeByte = buffReceiver[8]; // The data bytes received.
                bool[] temp = null;

                if (function != buffReceiver[7])
                {
                    byte[] byteMsg = new byte[9];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length);
                    byte[] data = new byte[SizeByte];
                    txtReceiMsg.Text = Display(byteMsg);

                    byte[] errorbytes = new byte[3];
                    Array.Copy(buffReceiver, 6, errorbytes, 0, errorbytes.Length);
                    this.CheckValidate(errorbytes); // Check validate
                }
                else
                {
                    byte[] byteMsg = new byte[9 + SizeByte];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length);
                    byte[] data = new byte[SizeByte];
                    txtReceiMsg.Text = Display(byteMsg); // Show received messages
                    Array.Copy(buffReceiver, 9, data, 0, data.Length);
                    temp = ByteToBool(data);
                }

                // Result
                if (temp == null) return;
                string result = string.Empty;
                foreach (var item in temp)
                {
                    result += string.Format("{0} ", item);
                }
                txtResult.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Write data
        /// </summary>
        /// <param name="frame">Frame communication</param>
        /// <returns>int</returns>
        public int Write(byte[] frame)
        {
            return this.mSocket.Send(frame, frame.Length, SocketFlags.None);
        }

        /// <summary>
        /// Read Data
        /// </summary>
        /// <returns>byte array</returns>
        public byte[] Read()
        {
            NetworkStream ns = new NetworkStream(this.mSocket);
            if (ns.CanRead)
            {
                int rs = this.mSocket.Receive(this.bufferReceiver, this.bufferReceiver.Length, SocketFlags.None);
            }
            return this.bufferReceiver;
        }

        /// <summary>
        /// Convert byte array to bool array.
        /// </summary>
        /// <param name="value">byte array</param>
        /// <returns>bool array</returns>
        private bool[] ByteToBool(byte[] value)
        {
            List<bool> result = new List<bool>();
            BitArray bits = new BitArray(value);
            for (int i = 0; i < bits.Count; i++)
            {
                result.Add(bits[i]);
            }
            return result.ToArray();
        }

        /// <summary>
        /// Function 02(02hex) Read Discrete Inputs
        /// Reads the ON/OFF status of discrete inputs in the slave.
        /// </summary>
        /// <param name="id">Slave id</param>
        /// <param name="slaveAddress">Slave Address</param>
        /// <param name="startAddress">Starting Address</param>
        /// <param name="function">Function</param>
        /// <param name="numberOfPoints">Quantity of Coils</param>
        /// <returns>Byte Array</returns>
        private byte[] ReadDiscreteInputsMsg(ushort id, byte slaveAddress, ushort startAddress, byte function, uint numberOfPoints)
        {
            byte[] frame = new byte[12];
            frame[0] = (byte)(id >> 8);	// Transaction Identifier High
            frame[1] = (byte)id; // Transaction Identifier Low
            frame[2] = 0; // Protocol Identifier High
            frame[3] = 0; // Protocol Identifier Low
            frame[4] = 0; // Message Length High
            frame[5] = 6; // Message Length Low(6 bytes to follow)
            frame[6] = slaveAddress; // Slave address(Unit Identifier)
            frame[7] = function; // Function             
            frame[8] = (byte)(startAddress >> 8); // Starting Address High
            frame[9] = (byte)startAddress; // Starting Address Low           
            frame[10] = (byte)(numberOfPoints >> 8); // Quantity of Coils High
            frame[11] = (byte)numberOfPoints; // Quantity of Coils Low
            return frame;
        }

        /// <summary>
        /// Check validate
        /// </summary>
        /// <param name="messageReceived">frame</param>
        public void CheckValidate(byte[] messageReceived)
        {
            try
            {
                switch (messageReceived[1])
                {

                    case 129: // Hex: 81                     
                    case 130: // Hex: 82 
                    case 131: // Hex: 83 
                    case 132: // Hex: 83 
                    case 133: // Hex: 84 
                    case 134: // Hex: 86 
                    case 143: // Hex: 8F 
                    case 144: // Hex: 90
                        switch (messageReceived[2])
                        {
                            case 1:
                                throw new Exception("01/0x01: Illegal Function.");
                            case 2:
                                throw new Exception("02/0x02: Illegal Data Address.");
                            case 3:
                                throw new Exception("03/0x03: Illegal Data Value.");
                            case 4:
                                throw new Exception("04/0x04: Failure In Associated Device.");
                            case 5:
                                throw new Exception("05/0x05: Acknowledge.");
                            case 6:
                                throw new Exception("06/0x06: Slave Device Busy.");
                            case 7:
                                throw new Exception("07/0x07: NAK – Negative Acknowledgements.");
                            case 8:
                                throw new Exception("08/0x08: Memory Parity Error.");
                            case 10:
                                throw new Exception("10/0x0A: Gateway Path Unavailable.");
                            case 11:
                                throw new Exception("11/0x0B: Gateway Target Device Failed to respond.");
                            default:
                                break;
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.Message;
            }
        } 


        /// <summary>
        /// Display Data
        /// </summary>
        /// <param name="data">Data</param>
        /// <returns>Message</returns>
        private string Display(byte[] data)
        {
            string result = string.Empty;
            foreach (var item in data)
            {
                result += string.Format("{0:X2}", item);
            }
            return result;
        }


    }
}
