﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FC05_WRITE_SINGLE_COIL
{
    public partial class FormMain : Form
    {
        private const int READ_BUFFER_SIZE = 12; // Size of message
        private const int WRITE_BUFFER_SIZE = 12; // Size of message

        private byte[] bufferReceiver = null;
        private byte[] bufferSender = null;

        private Socket mSocket = null;

        private string IP = "127.0.0.1";
        private int Port = 502;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            try
            {
                Connect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                Disconnect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Connect to device
        /// </summary>
        public void Connect()
        {
            this.mSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.bufferReceiver = new byte[READ_BUFFER_SIZE];
            this.bufferSender = new byte[WRITE_BUFFER_SIZE];
            this.mSocket.SendBufferSize = READ_BUFFER_SIZE;
            this.mSocket.ReceiveBufferSize = WRITE_BUFFER_SIZE;
            IPEndPoint server = new IPEndPoint(IPAddress.Parse(this.IP), this.Port);
            this.mSocket.Connect(server);
        }

        /// <summary>
        /// Disconnect with device
        /// </summary>
        public void Disconnect()
        {
            if (this.mSocket == null) return;
            if (this.mSocket.Connected)
            {
                this.mSocket.Close();
            }
        }

        private void btnON_Click(object sender, EventArgs e)
        {
            try
            {

                byte slaveAddress = 1;
                byte function = 5;
                ushort id = function;
                ushort startAddress = 0;
                const bool ON = true;
                txtErrors.Text = string.Empty;

                byte[] frame = WriteSingleCoilMsg(id, slaveAddress, startAddress, function, ON);
                txtSendMsg.Text = Display(frame); //Show Message sent
                this.Write(frame); // Send message
                Thread.Sleep(100); // Delay 100ms   

                // Process data.
                byte[] buffReceiver = this.Read(); // Receive messages  
                int SizeByte = buffReceiver[8]; // The data bytes received.    
                byte[] byteMsg = null;

                if (function != buffReceiver[7])
                {
                    byte[] errorbytes = new byte[3];
                    Array.Copy(buffReceiver, 6, errorbytes, 0, errorbytes.Length);
                    this.CheckValidate(errorbytes); // Check validate

                    byteMsg = new byte[9];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length);
                }
                else
                {
                    byteMsg = new byte[READ_BUFFER_SIZE];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length);
                }

                // Result
                txtReceiMsg.Text = Display(byteMsg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnOFF_Click(object sender, EventArgs e)
        {
            try
            {

                byte slaveAddress = 1;
                byte function = 5;
                ushort id = function;
                ushort startAddress = 0;
                const bool OFF = false;
                txtErrors.Text = string.Empty;

                byte[] frame = WriteSingleCoilMsg(id, slaveAddress, startAddress, function, OFF);
                txtSendMsg.Text = Display(frame); //Show Message sent
                this.Write(frame); // Send message
                Thread.Sleep(100); // Delay 100ms                                         

                // Process data.
                byte[] buffReceiver = this.Read(); // Receive messages  
                int SizeByte = buffReceiver[8]; // The data bytes received.    
                byte[] byteMsg = null;   

                if (function != buffReceiver[7])
                {
                    byte[] errorbytes = new byte[3];
                    Array.Copy(buffReceiver, 6, errorbytes, 0, errorbytes.Length);
                    this.CheckValidate(errorbytes); // Check validate

                    byteMsg = new byte[9];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length); 
                }
                else
                {
                    byteMsg = new byte[READ_BUFFER_SIZE];
                    Array.Copy(buffReceiver, 0, byteMsg, 0, byteMsg.Length);     
                }

                // Result
                if (byteMsg == null) return;
                txtReceiMsg.Text = Display(byteMsg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Write data
        /// </summary>
        /// <param name="frame">Frame communication</param>
        /// <returns>int</returns>
        public int Write(byte[] frame)
        {
            return this.mSocket.Send(frame, frame.Length, SocketFlags.None);
        }

        /// <summary>
        /// Read Data
        /// </summary>
        /// <returns>byte array</returns>
        public byte[] Read()
        {
            NetworkStream ns = new NetworkStream(this.mSocket);
            if (ns.CanRead)
            {
                int rs = this.mSocket.Receive(this.bufferReceiver, this.bufferReceiver.Length, SocketFlags.None);
            }
            return this.bufferReceiver;
        }


        /// <summary>
        /// Function 05 (05hex) Write Single Coil
        /// Writes a single coil to either ON or OFF.
        /// </summary>
        /// <param name="id">Slave id</param>
        /// <param name="slaveAddress">Slave Address</param>
        /// <param name="startAddress">Starting Address</param>
        /// <param name="function">Function</param>
        /// <param name="numberOfPoints">Quantity of Coils</param>
        /// <returns>Byte Array</returns>
        private byte[] WriteSingleCoilMsg(ushort id, byte slaveAddress, ushort startAddress, byte function, bool value)
        {
            byte[] frame = new byte[12];
            frame[0] = (byte)(id >> 8); // Slave id high byte
            frame[1] = (byte)id; // Slave id low byte
            frame[2] = 0; // Protocol Identifier High
            frame[3] = 0; // Protocol Identifier Low
            frame[4] = 0; // Message Length High
            frame[5] = 6; // Message Length Low(6 bytes to follow)
            frame[6] = slaveAddress; // Slave address(Unit Identifier)
            frame[7] = function; // Function               
            frame[8] = (byte)(startAddress >> 8); // Starting Address High
            frame[9] = (byte)startAddress; // Starting Address Low 
            frame[10] = (byte)(value ? 0xFF : 0x0); //Write Data High
            frame[11] = 0x00; //Write Data Low
            return frame;
        }

        /// <summary>
        /// Check validate
        /// </summary>
        /// <param name="messageReceived">frame</param>
        public void CheckValidate(byte[] messageReceived)
        {
            try
            {                
                switch (messageReceived[1])
                {

                    case 129: // Hex: 81                     
                    case 130: // Hex: 82 
                    case 131: // Hex: 83 
                    case 132: // Hex: 83 
                    case 133: // Hex: 84 
                    case 134: // Hex: 86 
                    case 143: // Hex: 8F 
                    case 144: // Hex: 90
                        switch (messageReceived[2])
                        {
                            case 1:
                                throw new Exception("01/0x01: Illegal Function.");
                            case 2:
                                throw new Exception("02/0x02: Illegal Data Address.");
                            case 3:
                                throw new Exception("03/0x03: Illegal Data Value.");
                            case 4:
                                throw new Exception("04/0x04: Failure In Associated Device.");
                            case 5:
                                throw new Exception("05/0x05: Acknowledge.");
                            case 6:
                                throw new Exception("06/0x06: Slave Device Busy.");
                            case 7:
                                throw new Exception("07/0x07: NAK – Negative Acknowledgements.");
                            case 8:
                                throw new Exception("08/0x08: Memory Parity Error.");
                            case 10:
                                throw new Exception("10/0x0A: Gateway Path Unavailable.");
                            case 11:
                                throw new Exception("11/0x0B: Gateway Target Device Failed to respond.");
                            default:
                                break;
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                txtErrors.Text = ex.Message;
            }            
        }        

        /// <summary>
        /// Display Data
        /// </summary>
        /// <param name="data">Data</param>
        /// <returns>Message</returns>
        private string Display(byte[] data)
        {
            string result = string.Empty;
            foreach (var item in data)
            {
                result += string.Format("{0:X2}", item);
            }
            return result;
        }
    }
}
